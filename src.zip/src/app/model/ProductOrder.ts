export class ProductOrder{
    cartid:number
    total:number
    uqty:number
    image_url:string
    pname:string
    constructor()
    {
        this.cartid=0
        this.total=0
        this.uqty=0
        this.image_url=''
        this.pname=''
    }
}