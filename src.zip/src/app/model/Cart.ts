export class Cart {
    pid: number
    uid: number
    cid: number
    ofk: number
    uqty: number
    total: number
    status: boolean
    fk: number
    pfk: number

    constructor() {
        this.pid = 0
        this.ofk = 0
        this.cid = 0
        this.uqty = 0
        this.total = 0
        this.status = false
        this.fk = 0
        this.pfk = 0
    }
}
