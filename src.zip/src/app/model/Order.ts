export class Order {
    oid:number
    total:number
    ufk:number
    id:number
    
    constructor() {
        this.oid=0
        this.total=0
        this.id=0
        this.ufk=0
    }
}