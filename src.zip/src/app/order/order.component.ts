import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { Order } from '../model/Order';

import { AuthenticateService } from '../authenticate.service';
import { ProductOrder } from '../model/ProductOrder';
import { Router } from '@angular/router';

@Component({
  selector: 'app-order',
  templateUrl: './order.component.html',
  styleUrls: ['./order.component.css']
})
export class OrderComponent implements OnInit {
  viewOrderedProductStatus:boolean
  constructor(public cartService: CartService, public authService: AuthenticateService,public router: Router) {
   this.viewOrderedProductStatus=false
  }

  ngOnInit() {
  }

  ProductOrdersDetail(id: number, oid: number) {
    this.cartService.getProductOrdersDetail(id, oid).subscribe((res: ProductOrder[]) => {
      if (res) {
        this.cartService.productOrderDetails = res
        this.viewOrderedProductStatus=true
        this.router.navigateByUrl('/orderedview')

      }
    })
  }

}
