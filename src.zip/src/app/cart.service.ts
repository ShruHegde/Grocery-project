import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { User } from './model/User';
import { environment } from '../environments/environment';
import { Cart } from './model/Cart';
import { Order } from './model/Order';
import { ProductOrder } from './model/ProductOrder';


const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Injectable({
  providedIn: 'root'
})
export class CartService {
  carts: Cart[]
  orders: Order[]
  productOrderDetails:ProductOrder[]

  constructor(public http: HttpClient) {

  }

  addToCart(cart: Cart) {
    return this.http.post('http://172.18.218.134:' + environment.port + '/grocery/cart/save', cart, httpOptions)
  }

  getCartByUid(uid: number) {
    return this.http.get('http://172.18.218.134:' + environment.port + '/grocery/cart/all/' + uid, httpOptions)
  }

  deleteCartItem(cartid: number) {
    return this.http.delete('http://172.18.218.134:' + environment.port + '/grocery/cart/delete/' + cartid, httpOptions)
  }

  placeOrder(order: Order) {
    return this.http.post('http://172.18.218.134:' + environment.port + '/grocery/order/add', order, httpOptions)
  }

  getMyOrder(uid: number) {
    return this.http.get('http://172.18.218.134:' + environment.port + '/grocery/order/all/' + uid, httpOptions)
  }
  getProductOrdersDetail(id:number,oid:number)
  {
    return this.http.get('http://172.18.218.134:' + environment.port + '/grocery/order/details/' + id +'/'+oid, httpOptions)
  }

}
