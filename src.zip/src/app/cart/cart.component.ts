import { Component, OnInit } from '@angular/core';
import { Router, Event, NavigationEnd } from '@angular/router';
import { Cart } from './../model/Cart';
import { Order } from './../model/Order';
import { Status } from './../model/Status';
import { AuthenticateService } from '../authenticate.service';
import { CartService } from './../cart.service';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';

const httpOptions = {
  headers: new HttpHeaders({
    'Authorization': 'someToken'
  }),
  withCredentials: true
};

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})

export class CartComponent implements OnInit {
  cart: Cart

  order: Order
  no: number
  successFlag: boolean
  progressFlag: boolean

  constructor(public cartService: CartService, public authService: AuthenticateService, public router: Router, public http: HttpClient) {
    this.order = new Order()
    this.no = 0
    this.cart = new Cart()
    this.successFlag = false
    this.cartService.orders = []
  }

  deleteCartItem(cartid, index) {
    this.cartService.deleteCartItem(cartid)
      .subscribe((res: Status) => {
        if (res.queryStatus)
          this.cartService.carts.splice(index, 1)
      })
  }

  ngOnInit() {
  }

  placeOrder(id) {

    this.successFlag = false

    for (let i = 0; i < this.cartService.carts.length; i++) {
      this.no = this.cartService.carts[i].total + this.no
      this.cartService.carts[i].status = true
    }

    this.order.ufk = this.authService.currentUser.id
    this.order.oid = 0
    this.order.total = this.no

    this.cartService.placeOrder(this.order).subscribe((res: Order) => {
      if (res !== null) {

        this.cartService.carts.forEach((cart: any, i) => {
          cart.status = true
          cart.ofk = res.oid

          this.http.put('http://172.18.218.134:' + environment.port + '/grocery/cart/edit', cart, httpOptions)
            .subscribe(res => {
              if (i == this.cartService.carts.length - 1)
                this.cartService.getCartByUid(cart.user.id).subscribe((res: Cart[]) => {
                  this.cartService.carts = res
                  this.successFlag = true
                })
            })
        })
      }
    }, err => {
      console.log(err)
    })



  }
}
