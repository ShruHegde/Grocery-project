import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { OrderedProductDetailsComponent } from './ordered-product-details.component';

describe('OrderedProductDetailsComponent', () => {
  let component: OrderedProductDetailsComponent;
  let fixture: ComponentFixture<OrderedProductDetailsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ OrderedProductDetailsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(OrderedProductDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
