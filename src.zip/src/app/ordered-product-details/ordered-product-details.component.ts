import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'app-ordered-product-details',
  templateUrl: './ordered-product-details.component.html',
  styleUrls: ['./ordered-product-details.component.css']
})
export class OrderedProductDetailsComponent implements OnInit {

  constructor(public cartService:CartService) { }

  ngOnInit() {
  }

}
